# Correção da página de configurações

Foram corrigidos dois arquivos do projeto SmartInspect:

- `configuracoes.html`: removido o JavaScript duplicado embutido na página e adicionada a referência única para `js/configuracoes.js`.
- `js/configuracoes.js`: reescrito para usar os IDs que existem no HTML, aplicar as classes CSS no elemento `body`, carregar e salvar as preferências no `localStorage` e remover o bloco inválido de Markdown que causava erro de sintaxe.

## Como aplicar

Substitua no repositório os arquivos `configuracoes.html` e `js/configuracoes.js` pelos arquivos desta pasta. Depois, faça um commit e publique novamente o projeto.

## Validação realizada

A sintaxe do JavaScript foi validada com `node --check`, o HTML passou pela conferência de referência do script e o diff não apresentou erros de espaço ou conflito. A página local redireciona para `login.html` porque o próprio projeto possui proteção de autenticação; por isso, a tela de configurações precisa ser aberta após o login.
